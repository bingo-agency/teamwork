import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class City extends StatelessWidget {
  const City({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(18.0),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                  child: Card(
                elevation: 10.0,
                child: Text('Islamabad'),
              )),
              Container(
                child: Card(
                  elevation: 10.0,
                  child: Text('Lahore'),
                ),
              ),
              Container(
                child: Card(
                  elevation: 10.0,
                  child: Text('Peshawar'),
                ),
              )
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                child: Card(
                  elevation: 10.0,
                  child: Text('Abbotabad'),
                ),
              ),
              Container(
                child: Card(
                  elevation: 10.0,
                  child: Text('Karachi'),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
