import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:team_work/models/house.dart';
import 'package:team_work/widgets/circle_icon_button.dart';

import '../models/database.dart';

class Listing extends StatelessWidget {
  // final listOfOffer = House.generateBestOffer();

  @override
  Widget build(BuildContext context) {
    context.read<DataBase>().fetchListing;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 20),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Listing',
                style: Theme.of(context)
                    .textTheme
                    .headline1!
                    .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              Text(
                'View All',
                style: Theme.of(context)
                    .textTheme
                    .bodyText1!
                    .copyWith(fontSize: 14, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          SizedBox(height: 10),
          // here it starts
          Consumer<DataBase>(
            builder: (context, value, child) {
              return value.mapListing.isEmpty && !value.errorListing
                  ? const Center(child: CircularProgressIndicator())
                  : value.errorListing
                      ? Text(
                          'Oops, something went wrong .${value.errorMessageListing}',
                          textAlign: TextAlign.center,
                        )
                      : ListView.builder(
                          scrollDirection: Axis.vertical,
                          physics: const ClampingScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: value.mapListing['nonfeatured'].length,
                          itemBuilder: (context, index) {
                            return ListingCard(
                                map: value.mapListing['nonfeatured'][index]);
                          },
                        );
            },
          ),
        ],
      ),
    );
  }
}

class ListingCard extends StatelessWidget {
  const ListingCard({Key? key, required this.map}) : super(key: key);

  final Map<String, dynamic> map;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(8)),
      child: Stack(
        children: [
          Row(
            children: [
              Container(
                width: 150,
                height: 80,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: NetworkImage(map['primary_image']),
                        fit: BoxFit.cover),
                    borderRadius: BorderRadius.circular(8)),
              ),
              SizedBox(width: 10),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      map['title'],
                      style: Theme.of(context)
                          .textTheme
                          .headline1!
                          .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 10),
                    Row(
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          color: Theme.of(context).primaryColor,
                        ),
                        Text(
                          map['address'],
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(fontSize: 12),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          Positioned(
            right: 0,
            child: Text(
              map['price'] + ' PKR',
              style: Theme.of(context).textTheme.displaySmall!.copyWith(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Colors.purple),
            ),

            // CircleIconButton(
            //   iconUrl: 'assets/icons/heart.svg',
            //   color: Colors.grey,
            // ),
          )
        ],
      ),
    );
  }
}
